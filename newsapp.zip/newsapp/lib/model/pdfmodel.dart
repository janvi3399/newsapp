class Pdfmodel {
  String? title;
  String? description;
  String? content;
  String? url;
  String? urlimg;

  Pdfmodel({
    required this.title,
    required this.description,
    required this.content,
    required this.url,
    required this.urlimg,
  });
}
